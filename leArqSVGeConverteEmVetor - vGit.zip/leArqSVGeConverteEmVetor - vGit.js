const fs = require('fs');
const { JSDOM } = require('jsdom');

// Função para processar um caminho SVG e extrair coordenadas
const pathToCoordinates = (path) => {
  const commands = path.match(/[MLHVCSQTAZmlhvcsqtaz][^MLHVCSQTAZmlhvcsqtaz]*/g);
  let currentX = 0;
  let currentY = 0;
  let startX = 0;
  let startY = 0;
  const coordinates = [];

  commands.forEach(segment => {
    const command = segment[0];
    const values = segment.slice(1).trim().split(/[ ,]+/).map(Number);

    switch (command) {
      case "M": // Movimento absoluto
        for (let i = 0; i < values.length; i += 2) {
          const x = values[i];
          const y = values[i + 1];
          coordinates.push({ x, y });
          currentX = x;
          currentY = y;
          if (i === 0) {
            startX = x;
            startY = y;
          }
        }
        break;

      case "m": // Movimento relativo
        for (let i = 0; i < values.length; i += 2) {
          const x = currentX + values[i];
          const y = currentY + values[i + 1];
          coordinates.push({ x, y });
          currentX = x;
          currentY = y;
          if (i === 0) {
            startX = x;
            startY = y;
          }
        }
        break;

      case "L": // Linha absoluta
        for (let i = 0; i < values.length; i += 2) {
          const x = values[i];
          const y = values[i + 1];
          coordinates.push({ x, y });
          currentX = x;
          currentY = y;
        }
        break;

      case "l": // Linha relativa
        for (let i = 0; i < values.length; i += 2) {
          const x = currentX + values[i];
          const y = currentY + values[i + 1];
          coordinates.push({ x, y });
          currentX = x;
          currentY = y;
        }
        break;

      case "C": // Curvas absolutas
        for (let i = 0; i < values.length; i += 6) {
          const control1X = values[i];
          const control1Y = values[i + 1];
          const control2X = values[i + 2];
          const control2Y = values[i + 3];
          const endX = values[i + 4];
          const endY = values[i + 5];

          coordinates.push({ x: control1X, y: control1Y });
          coordinates.push({ x: control2X, y: control2Y });
          coordinates.push({ x: endX, y: endY });

          currentX = endX;
          currentY = endY;
        }
        break;

      case "c": // Curvas relativas
        for (let i = 0; i < values.length; i += 6) {
          const control1X = currentX + values[i];
          const control1Y = currentY + values[i + 1];
          const control2X = currentX + values[i + 2];
          const control2Y = currentY + values[i + 3];
          const endX = currentX + values[i + 4];
          const endY = currentY + values[i + 5];

          coordinates.push({ x: control1X, y: control1Y });
          coordinates.push({ x: control2X, y: control2Y });
          coordinates.push({ x: endX, y: endY });

          currentX = endX;
          currentY = endY;
        }
        break;

      case "Z":
      case "z": // Fechamento de caminho
        coordinates.push({ x: startX, y: startY });
        currentX = startX;
        currentY = startY;
        break;

      default:
        console.warn(`Comando SVG não suportado: ${command}`);
        break;
    }
  });

  return coordinates;
};

// Função para extrair coordenadas e agrupar por cores
const extractCoordinatesGroupedByColor = (svgFilePath) => {
  try {
    const svgContent = fs.readFileSync(svgFilePath, 'utf-8');
    const dom = new JSDOM(svgContent);
    const paths = dom.window.document.querySelectorAll('path');

    const groupedData = {};

    paths.forEach((pathElement, index) => {
      const d = pathElement.getAttribute('d');
      const fill = pathElement.getAttribute('style') || 'undefined';
      const strFill=fill.split("#")[1].split(";")[0]
      //console.log(strFill);
      const groupKey = `VetoresCor_#${strFill}`;

      const coordinates = pathToCoordinates(d);

      if (!groupedData[groupKey]) {
        groupedData[groupKey] = [];
      }

      groupedData[groupKey].push({ pathIndex: index + 1, coordinates });
    });

    return groupedData;
  } catch (error) {
    console.error("Erro ao ler ou processar o arquivo SVG:", error);
    return null;
  }
};

// Função para salvar coordenadas em um arquivo
const saveToFile = (data, outputPath) => {
    try {
      fs.writeFileSync(outputPath, JSON.stringify(data, null, 2));
      console.log(`Resultado salvo em: ${outputPath}`);
    } catch (error) {
      console.error("Erro ao salvar o arquivo:", error);
    }
  };


/////////////////////////////////////////////////////////////////////////////////////////////////////////
//const svgFileExemplo = 'caminho/do/arquivo.svg'; // Substitua pelo caminho do arquivo SVG
const svgFile = "img_entrada.svg"
///////////////////////////////////////////////////////////////////////////////////////////////////////////

//const result = extractCoordinatesFromSVG(svgFile);
const result = extractCoordinatesGroupedByColor(svgFile);

if (result) {

    const vetoresAgrupados = Object.keys(result).reduce((cores, key) => {
        cores[key] = result[key].reduce((coords, item) => {
          coords.push(...item.coordinates); // Adiciona as coordenadas do item no array
          return coords;
        }, []);
        return cores;
      }, {});
  
    // Criação do nome do arquivo com data e hora
    const now = new Date();
    const timestamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}_${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}${String(now.getSeconds()).padStart(2, '0')}`;
    const outputDir = './saida';
    const outputFile = `${outputDir}/vetores_SVG_${timestamp}.txt`;
  
    // Garantir que o diretório de saída exista
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir);
    }
  
    // Salvar o resultado no arquivo
    saveToFile(vetoresAgrupados, outputFile);
  }
