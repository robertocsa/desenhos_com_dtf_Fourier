// Based upon (baseado em):

// Coding Challenge 130.1: Drawing //with Fourier Transform and Epicycles
// Daniel Shiffman
// https://thecodingtrain.com/CodingChallenges/130-fourier-transform-drawing.html
// https://youtu.be/MY4luNgGfms

let vetoresCor;
let drawing = [];
let paths = [];
const scaleFactor = 6; // Fator de escala para aumentar o tamanho das letras

// Mapeamento de cores para as chaves do JSON
const colorMap = {
  'VetoresCor_#0000a0': '#0000a0',
  'VetoresCor_#008000': '#008000',
  'VetoresCor_#ff6600': '#ff6600'
};

function setupDrawing() {
  if (vetoresCor) {
    let drawingR = vetoresCor['VetoresCor_#0000a0'] || [];
    let drawingC = vetoresCor['VetoresCor_#008000'] || [];
    let drawingS = vetoresCor['VetoresCor_#ff6600'] || [];

    drawing = [
      { data: drawingR, color: colorMap['VetoresCor_#0000a0'], time: 0 },
      { data: drawingC, color: colorMap['VetoresCor_#008000'], time: 0 },
      { data: drawingS, color: colorMap['VetoresCor_#ff6600'], time: 0 }
    ];

    // Escalando os vetores e calculando as transformadas de Fourier
    drawing.forEach(group => {
      let xGroup = [];
      let yGroup = [];
      for (let i = 0; i < group.data.length; i++) {
        xGroup.push(group.data[i].x * scaleFactor); // Aplicando escala
        yGroup.push(group.data[i].y * scaleFactor);
      }
      group.fourierX = dft(xGroup);
      group.fourierY = dft(yGroup);
      paths.push([]); // Caminho para cada grupo
    });
  }
}

function preload() {
  loadJSON('./vetores.json', (data) => {
    vetoresCor = data;
    setupDrawing();
  });
}

function setup() {
  createCanvas(600, 500);
  frameRate(25);
}

function epiCycles(x, y, rotation, fourier, time) {
  for (let i = 0; i < fourier.length; i++) {
    let prevx = x;
    let prevy = y;
    let freq = fourier[i].freq;
    let radius = fourier[i].amp;
    let phase = fourier[i].phase;
    x += radius * cos(freq * time + phase + rotation);
    y += radius * sin(freq * time + phase + rotation);

    // Desenhar círculos auxiliares 
    if ( i > 0) {      
      stroke(100);
      noFill();
      ellipse(x, y, radius * 2);
    }
  }
  return createVector(x, y);
}


function draw() {
  background(255);

  if (drawing.length > 0) {
    drawing.forEach((group, index) => {
      let color = group.color;

      // Ajuste da posição inicial para cada grupo
      let initialX = width / 25 + index * 20;
      let initialY = height / 4 - 100;
      
      let vx = epiCycles(initialX, initialY+350, 0, group.fourierX, group.time);
      let vy = epiCycles(initialX+420, initialY, HALF_PI, group.fourierY, group.time);

      let v = createVector(vx.x, vy.y);
      paths[index].unshift(v);

      // Conexões auxiliares
      stroke(0);
      dashedLine(vx.x, vx.y, v.x, v.y);
      dashedLine(vy.x, vy.y, v.x, v.y);

      // Desenho do caminho acumulado
      fill(color);
      noStroke();
      beginShape();
      for (let i = 0; i < paths[index].length; i++) {
        vertex(paths[index][i].x, paths[index][i].y);
      }
      endShape(CLOSE);

      // Atualização do tempo para o grupo
      const dt = (TWO_PI / group.fourierX.length);
      group.time += dt;

      // Reinicia o tempo do grupo após o ciclo
      if (group.time > TWO_PI) {
        group.time = 0;
        paths[index] = [];
      }
    });
  } else {
    fill(255);
    textAlign(CENTER, CENTER);
    text('Carregando dados...', width / 2, height / 2);
  }
}

function dft(x) {
  const X = [];
  const N = x.length;
  for (let k = 0; k < N; k++) {
    let re = 0;
    let im = 0;
    for (let n = 0; n < N; n++) {
      const phi = (TWO_PI * k * n) / N;
      re += x[n] * cos(phi);
      im -= x[n] * sin(phi);
    }
    re = re / N;
    im = im / N;

    let freq = k;
    let amp = sqrt(re * re + im * im);
    let phase = atan2(im, re);
    X[k] = { re, im, freq, amp, phase };
  }
  return X;
}

function dashedLine(x1, y1, x2, y2, dashLength = 5, gapLength = 5) {
  const totalLength = dist(x1, y1, x2, y2);
  const steps = dashLength + gapLength;
  const numDashes = Math.floor(totalLength / steps);

  const deltaX = (x2 - x1) / totalLength;
  const deltaY = (y2 - y1) / totalLength;

  for (let i = 0; i <= numDashes; i++) {
    const start = i * steps;
    const end = Math.min(start + dashLength, totalLength);

    const startX = x1 + deltaX * start;
    const startY = y1 + deltaY * start;
    const endX = x1 + deltaX * end;
    const endY = y1 + deltaY * end;

    line(startX, startY, endX, endY);
  }
}
